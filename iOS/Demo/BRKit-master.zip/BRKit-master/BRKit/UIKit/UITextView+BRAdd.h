//
//  UITextView+BRAdd.h
//  BRKitDemo
//
//  Created by 任波 on 2018/5/11.
//  Copyright © 2018年 91renb. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITextView (BRAdd)
/** UITextView 的最大输入长度 */
//@property (nonatomic, assign) NSInteger inputLimit;

@end
