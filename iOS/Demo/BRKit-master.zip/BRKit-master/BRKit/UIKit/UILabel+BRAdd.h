//
//  UILabel+BRAdd.h
//  AFNetworking
//
//  Created by 任波 on 2018/5/2.
//  Copyright © 2018年 91renb. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (BRAdd)
@property (nonatomic, assign) BOOL copyable;

@end
